// Password admin yang valid
const ADMIN_PASSWORD = "141224";
let isAdmin = false;

function showSection(id) {
  document.querySelectorAll("main section").forEach(s => s.style.display = "none");
  document.getElementById(id).style.display = "block";
}

function login() {
  const pass = document.getElementById("passwordInput").value;
  if (pass === ADMIN_PASSWORD) {
    isAdmin = true;
    alert("Login berhasil! Selamat datang, Agung Maulana.");
    document.getElementById("adminBtn").style.display = "inline-block";
    document.getElementById("passwordInput").style.display = "none";
    document.querySelector("#loginSection button:first-child").style.display = "none";
    document.getElementById("logoutBtn").style.display = "inline-block";
    showSection("adminPanel");
    loadProfileToForm();
    renderWorks();
  } else {
    alert("Password salah!");
  }
}

function logout() {
  isAdmin = false;
  alert("Anda telah logout.");
  document.getElementById("adminBtn").style.display = "none";
  document.getElementById("passwordInput").style.display = "inline-block";
  document.querySelector("#loginSection button:first-child").style.display = "inline-block";
  document.getElementById("logoutBtn").style.display = "none";
  document.getElementById("passwordInput").value = "";
  showSection("home");
  renderWorks();
}

// (Other script logic omitted for brevity)
document.getElementById("adminBtn").addEventListener("click", () => showSection("adminPanel"));

function init() {
  showSection("home");
  renderWorks();
  renderProfile();
}

init();
